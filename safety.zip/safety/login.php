<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Safety First - Make The World A Better Place | Contact</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/bear.png">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">

</head>
<script>
function validateForm() {
    var x = document.forms["myForm"]["username"].value;
	var y = document.forms["myForm"]["password"].value;

    if (x == "" || y== "") {
        alert("All the field must be filled out");
        return false;
    }
}
</script>
<style>
a:link {
    font-size: 100%;
	color: blue;
}

a:visited {
    color: blue;
}

a:hover {
    font-size: 115%;
	color: red;
}

a:active {
    color: yellow;
}
</style>
<script>
	function startTime() {
		var today = new Date();
		var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
		var d = today.getDate();
		var mn = today.getMonth();
		var y = today.getFullYear();
		var h = today.getHours();
		var m = today.getMinutes();
		var s = today.getSeconds();
		m = checkTime(m);
		s = checkTime(s);
		document.getElementById('txt').innerHTML =
		d + " " + months[today.getMonth()] + " " + y + " " + h + ":" + m + ":" + s;
		var t = setTimeout(startTime, 500);
	}
	function checkTime(i) {
		if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
		return i;
	}
</script>
<body>						

<?php

session_start();

if (isset($_POST['username']) && isset($_POST['password']))
{
	$connect = mysqli_connect("localhost", "root", "") or die("Couldn't connect to database");
	mysqli_select_db($connect,"security") or die ("Couldn't find database");
	
	$query = "SELECT * FROM register WHERE username='".$_POST['username']."' AND password='".$_POST['password']."'";
	$result = mysqli_query($connect, $query);
	$row = mysqli_num_rows($result);
	
	$usernama=$_POST['username'];
	// Store Session Data
    $_SESSION['login_user']= strtoupper($usernama); // Initializing Session with value of PHP Variable
	
	if ($row > 0)
	{	
        
		header("Location: index.php");
	}
		
	else
		header ("Location: login1.php");
	}		

else
	{
	
?>

    <!-- Header Area Start -->
    <header class="header-area">
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <!-- Breaking News Area -->
                    <div class="col-12 col-md-6">
                        <div class="breaking-news-area">
                            <h5 class="breaking-news-title">Login now to view information</h5>
                        </div>
                    </div>
                    <!-- Stock News Area -->
                    <div class="col-12 col-md-6">
                        <div class="stock-news-area">
                            <div id="stockNewsTicker" class="ticker">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Middle Header Area -->
        <div class="middle-header">
            <div class="container h-100" >
                <div class="row h-100 align-items-center">
                    <!-- Logo Area -->
                    <div class="col-12 col-md-4">
                        <div class="logo-area">
                            <a href="index.php"><img src="img/core-img/headerlogo.jpg" alt="logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <!-- Breadcumb Area Start -->
    <div class="breadcumb-area section_padding_50">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breacumb-content d-flex align-items-center justify-content-between">
                        <h1 class="font-pt mb-0">Login</h1>
                        <body onload="startTime()">

						<div id="txt"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area End -->

    <section class="gazette-contact-area section_padding_100">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8">
                    <div class="gazette-heading">
                        <h1 class="font-bold">Login Your Acount</h1><br>
                    </div>

						
							
						<form name="myForm" action = "login.php" onsubmit="return validateForm()" method="post"><br><br>
									
										<div class="form-group">
                                        <b>Username :</b>
										<input type = "text" class="form-control" name = "username" > 
										</div>
										
										<div class="form-group">
										<b>Password :</b> 
										<input type = "password" class="form-control" name = "password"> 
										</div>
										
										<a href = "register.php"> <u>Not Yet Register?</u></a>			
										<br><br><br>
										
										<input type="submit" class="btn contact-btn" name="submitted" value='Login' >
										</div>
	
										</form>
										
						<?php 
	}
	?>

</body>
</html>