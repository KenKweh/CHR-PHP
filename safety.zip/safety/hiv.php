<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Safety First - Make The World A Better Place | Home</title>

    <!-- Safety Logo  -->
    <link rel="icon" href="img/core-img/bear.png">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">
	</head>
	<script>
	function startTime() {
		var today = new Date();
		var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
		var d = today.getDate();
		var mn = today.getMonth();
		var y = today.getFullYear();
		var h = today.getHours();
		var m = today.getMinutes();
		var s = today.getSeconds();
		m = checkTime(m);
		s = checkTime(s);
		document.getElementById('txt').innerHTML =
		d + " " + months[today.getMonth()] + " " + y + " " + h + ":" + m + ":" + s;
		var t = setTimeout(startTime, 500);
	}
	function checkTime(i) {
		if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
		return i;
	}
</script>
<?php
session_start();
                 
?>
<body>
    <!-- Header Area Start -->
    <header class="header-area">
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <!-- Breaking News Area -->
                    <div class="col-12 col-md-6">
                        <div class="breaking-news-area">
                            <h5 class="breaking-news-title">Safety Quotes</h5>
							<div id="breakingNewsTicker" class="ticker">
                                <ul>
                                    <li><a href="#">For safety is not a gadget but a state of mind.</a></li>
                                    <li><a href="#">Safety is as simple as ABC - Always Be Careful.</a></li>
                                    <li><a href="#">The desire for safety stands against every great and noble enterprise.</a></li>
                                    <li><a href="#">The dangers of life are infinite, and among them is safety.</a></li>
                                    <li><a href="#">It is better to be safe than sorry.</a></li>
                                    <li><a href="#">Safety is something that happens between your ears, not something you hold in your hands.</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- Stock News Area -->
                    <div class="col-12 col-md-6">
                        <div class="stock-news-area">
                            <div id="stockNewsTicker" class="ticker">
                                <ul>
                                    <li>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>Accident Rate</span>
                                                <span>2014</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>0.34</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>HIV RATE</span>
                                                <span>2014</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.27</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>THEFT RATE</span>
                                                <span>2014</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.22</h4>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>ACCIDENT RATE</span>
                                                <span>2015</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>0.11</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>HIV RATE</span>
                                                <span>2015</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>0.77</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>THEFT RATE</span>
                                                <span>2015</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>1.25</h4>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>ACCIDENT RATE</span>
                                                <span>2016</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.04</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>HIV RATE</span>
                                                <span>2016</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.08</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>THEFT RATE</span>
                                                <span>2016</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.12</h4>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Middle Header Area -->
        <div class="middle-header">
            <div class="container h-100" >
                <div class="row h-100 align-items-center">
                    <!-- Logo Area -->
                    <div class="col-12 col-md-4">
                        <div class="logo-area">
                            <a href="index.php"><img src="img/core-img/headerlogo.jpg" alt="logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Bottom Header Area -->
        <div class="bottom-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="main-menu">
                            <nav class="navbar navbar-expand-lg">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#gazetteMenu" aria-controls="gazetteMenu" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i> Menu</button>
                                <div class="collapse navbar-collapse" id="gazetteMenu">
                                    <ul class="navbar-nav mr-auto">
                                         <li class="nav-item">
                                            <a class="nav-link" href="index.php">Home</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="catagory.php">Category</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="about-us.php">About Us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="contact.php">Contact Us</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="login.php">Sign Out</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">Regional Setting</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">
											<?php
	
											if(empty($_COOKIE['country'])&&empty($_COOKIE['language']))
								{
									echo"&emsp; &emsp;Country: ";
									echo"-";
									
									echo"&emsp; Language: ";
									echo"-";
									
								}
								else
								{
									echo"Country: ";
									echo $_COOKIE['country'];
									
									echo"&emsp; Language: ";
									echo $_COOKIE['language'];
									
								}
							?></a>
                                        </li>
                                     </ul>
                                    <?php
									if(!empty($_SESSION['login_user'])){
										echo "USERNAME: ";
										echo $_SESSION['login_user']; 
									}
                                    else
                                        echo "";										
                                    ?>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->
	
		<!-- Main Content Area Start -->
    <section class="main-content-wrapper section_padding_0">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-9">
                    <!-- Gazette Welcome Post -->
                    <div class="gazette-welcome-post">
                        <!-- Post Tag -->
                        <div class="gazette-post-tag">
                           <h1 class="font-pt mb-0">SAFETY. FOR A CHANGE.</h1>
                        </div>
                        <h2 class="font-pt">How to prevent HIV?</h2>
                        <body onload="startTime()">

						<div id="txt"></div>
                        <!-- Post Thumbnail -->
                        <div class="blog-post-thumbnail my-5">
                            <img src="img/core-img/hiv.jpeg" alt="post-thumb">
                        </div>
                        <!-- Post Excerpt -->
                        <p>You can only get HIV through certain bodily fluids of an infected person (e.g. blood, semen, breast milk).</p>
						<p>HIV can be transmitted during unprotected sex; through sharing injecting equipment; from mother-to-baby during pregnancy, birth and breastfeeding; and through contaminated blood transfusions.</p>
						<p>HIV cannot survive outside the body. It cannot be spread through the air, from touching, toilet seats or shared cutlery.</p>
						<p>Using condoms during sex, or taking PrEP consistently will protect you from HIV infection through sex.</p>
						<p>Taking HIV treatment if you are a new or expectant mother, and avoiding shared injecting equipment if you use drugs, will also protect you and those around you from HIV.</p>
                        <!-- Reading More -->
                        <div class="post-continue-reading-share d-sm-flex align-items-center justify-content-between mt-30">
                            <div class="post-continue-btn">
                                <a href="https://www.mayoclinic.org/diseases-conditions/hiv-aids/symptoms-causes/syc-20373524" class="font-pt">Continue Reading <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                            </div>
                            <div class="post-share-btn-group">
                                <a href="https://www.pinterest.com"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                <a href="https://www.linkedin.com/"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                <a href="https://www.facebook.com/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="https://twitter.com/?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>

                    <div class="gazette-todays-post section_padding_100_50">
                        <div class="gazette-heading">
                            <h4>today’s most popular</h4>
                        </div>
                        <!-- Single Today Post -->
                        <div class="gazette-single-todays-post d-md-flex align-items-start mb-50">
                            <div class="todays-post-thumb">
                                <img src="img/blog-img/2.jpg" alt="">
                            </div>
                            <div class="todays-post-content">
                                <!-- Post Tag -->
                                <div class="gazette-post-tag">
                                    <a href="https://edition.cnn.com/style/article/most-expensive-home-250-million-usd/index.php">News</a>
                                </div>
                                <h3><a href="https://edition.cnn.com/style/article/most-expensive-home-250-million-usd/index.php" class="font-pt mb-2">$250-million mansion is most expensive</a></h3>
                                <span class="gazette-post-date mb-2">March 29, 2016</span>
                                <a href="#" class="post-total-comments">3 Comments</a>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse ultrices egestas nunc, quis venenatis orci tincidunt id. Fusce commodo blandit eleifend. Nullam viverra tincidunt dolor, at pulvinar dui. Nullam at risus ut ipsum viverra posuere.</p>
                            </div>
                        </div>
                        <!-- Single Today Post -->
                        <div class="gazette-single-todays-post d-md-flex align-items-start mb-50">
                            <div class="todays-post-thumb">
                                <img src="img/blog-img/3.jpg" alt="">
                            </div>
                            <div class="todays-post-content">
                                <!-- Post Tag -->
                                <div class="gazette-post-tag">
                                    <a href="https://edition.cnn.com/2017/12/13/europe/homeless-man-paris-airport-theft-intl/index.php">Life</a>
                                </div>
                                <h3><a href="https://edition.cnn.com/2017/12/13/europe/homeless-man-paris-airport-theft-intl/index.php" class="font-pt mb-2">Homeless man steals $350,000 </a></h3>
                                <p class="gazette-post-date mb-2">March 29, 2016</p>
                                <a href="#" class="post-total-comments">3 Comments</a>
                                <p>Aliquam quis convallis enim. Nunc pulvinar molestie sem id blandit. Nunc venenatis interdum mollis. Aliquam finibus nulla quam, a iaculis justo finibus non. Suspendisse in fermentum nunc.</p>
                            </div>
                        </div>
                    </div>
                </div>
	
                <div class="col-12 col-lg-3 col-md-6">
                    <div class="sidebar-area">
                        <!-- Breaking News Widget -->
                        <div class="breaking-news-widget">
                            <div class="widget-title">
                                <h5>breaking news</h5>
                            </div>
                            <!-- Single Breaking News Widget -->
                            <div class="single-breaking-news-widget">
                                <img src="img/core-img/wtf.jpg" alt="">
                                <div class="breakingnews-title">
                                    <p>breaking news</p>
                                </div>
                                <div class="breaking-news-heading gradient-background-overlay">
                                    <h5 class="font-pt">Four People Killed In Car Crash In Chula Vista</h5>
                                </div>
                            </div>
                            <!-- Single Breaking News Widget -->
                            <div class="single-breaking-news-widget">
                                <img src="img/core-img/hivs.jpeg" alt="">
                                <div class="breakingnews-title">
                                    <p>breaking news</p>
                                </div>
                                <div class="breaking-news-heading gradient-background-overlay">
                                    <h5 class="font-pt">HIV/AIDS cure finally FOUND Doctors</h5>
                                </div>
                            </div>
                        </div>

                        <!-- Don't Miss Widget -->
                        <div class="donnot-miss-widget">
                            <div class="widget-title">
                                <h5>Don't miss</h5>
                            </div>
                            <!-- Single Don't Miss Post -->
                            <div class="single-dont-miss-post d-flex mb-30">
                                <div class="dont-miss-post-thumb">
                                    <img src="img/blog-img/dm-1.jpg" alt="">
                                </div>
                                <div class="dont-miss-post-content">
                                    <a href="#" class="font-pt">EU council reunites</a>
                                    <span>Nov 29, 2017</span>
                                </div>
                            </div>
                            <!-- Single Don't Miss Post -->
                            <div class="single-dont-miss-post d-flex mb-30">
                                <div class="dont-miss-post-thumb">
                                    <img src="img/blog-img/dm-2.jpg" alt="">
                                </div>
                                <div class="dont-miss-post-content">
                                    <a href="#" class="font-pt">A new way to travel the world</a>
                                    <span>March 29, 2016</span>
                                </div>
                            </div>
                            <!-- Single Don't Miss Post -->
                            <div class="single-dont-miss-post d-flex mb-30">
                                <div class="dont-miss-post-thumb">
                                    <img src="img/blog-img/dm-3.jpg" alt="">
                                </div>
                                <div class="dont-miss-post-content">
                                    <a href="#" class="font-pt">Why choose a bank?</a>
                                    <span>March 29, 2016</span>
                                </div>
                            </div>
                        </div>
                        <!-- Advert Widget -->
                        <div class="advert-widget">
                            <div class="widget-title">
                                <h5>Insurance</h5>
                            </div>
                            <div class="advert-thumb mb-30">
                                <a href="https://prudential.com.my/"><img src="img/core-img/insurance.png" alt=""></a>
                            </div>
                        </div>
                        <!-- Subscribe Widget -->
                        <div class="subscribe-widget">
                            <div class="widget-title">
                                <h5>subscribe</h5>
                            </div>
                            <div class="subscribe-form">
                                <form action="#">
                                    <input type="email" name="email" id="subs_email" placeholder="Your Email" required>
                                    <button type="submit" name="Subscribed" onload="alert('Thanks for subscribing us')">subscribe</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Area End -->

	
	<!-- Bottom Footer Area -->
        <div class="bottom-footer-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12">
                        <div class="copywrite-text">
                            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area End -->
	
	 <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>