<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Safety First - Make The World A Better Place | Home</title>

    <!-- Safety Logo  -->
    <link rel="icon" href="img/core-img/bear.png">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">
	</head>

<script>
	function startTime() {
		var today = new Date();
		var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
		var d = today.getDate();
		var mn = today.getMonth();
		var y = today.getFullYear();
		var h = today.getHours();
		var m = today.getMinutes();
		var s = today.getSeconds();
		m = checkTime(m);
		s = checkTime(s);
		document.getElementById('txt').innerHTML =
		d + " " + months[today.getMonth()] + " " + y + " " + h + ":" + m + ":" + s;
		var t = setTimeout(startTime, 500);
	}
	function checkTime(i) {
		if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
		return i;
	}
</script>

<body>
<?php
session_start();   // Start the session

if(isset($_POST['submitted']))
	{
		$connect = mysqli_connect('localhost','root','');
		mysqli_select_db($connect,'security');
		$problem = FALSE;
		
		if(!empty($_POST['email']))
		{
			$email = trim($_POST['email']);
		}
		else
		{
			echo '<p style="color:red;">Please submit both of the feild.</p>';
			$problem = TRUE;
		}
		
		if(!$problem)
		{
			$query = "INSERT INTO subscribe (email) VALUES('$email')";
				
			if(@mysqli_query($connect,$query))
			{
				header('Location: index.php');
				exit();
			}
			else
			{
				echo '<p style="color:red;">Could not add the entry because:<br>'.mysqli_connect_error($connect).'.</p><p>The query was:'.$query.'</p>';
			}
		}	
			mysqli_close($connect);
	}
	else{         
?>

    <!-- Header Area Start -->
    <header class="header-area">
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <!-- Breaking News Area -->
                    <div class="col-12 col-md-6">
                        <div class="breaking-news-area">
                            <h5 class="breaking-news-title">Safety Quotes</h5>
							<div id="breakingNewsTicker" class="ticker">
                                <ul>
                                    <li><a href="#">For safety is not a gadget but a state of mind.</a></li>
                                    <li><a href="#">Safety is as simple as ABC - Always Be Careful.</a></li>
                                    <li><a href="#">The desire for safety stands against every great and noble enterprise.</a></li>
                                    <li><a href="#">The dangers of life are infinite, and among them is safety.</a></li>
                                    <li><a href="#">It is better to be safe than sorry.</a></li>
                                    <li><a href="#">Safety is something that happens between your ears, not something you hold in your hands.</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- Stock News Area -->
                    <div class="col-12 col-md-6">
                        <div class="stock-news-area">
                            <div id="stockNewsTicker" class="ticker">
                                <ul>
                                    <li>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>Accident Rate</span>
                                                <span>2014</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>0.34</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>HIV RATE</span>
                                                <span>2014</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.27</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>THEFT RATE</span>
                                                <span>2014</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.22</h4>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>ACCIDENT RATE</span>
                                                <span>2015</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>0.11</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>HIV RATE</span>
                                                <span>2015</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>0.77</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>THEFT RATE</span>
                                                <span>2015</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>1.25</h4>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>ACCIDENT RATE</span>
                                                <span>2016</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.04</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>HIV RATE</span>
                                                <span>2016</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.08</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>THEFT RATE</span>
                                                <span>2016</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.12</h4>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Middle Header Area -->
        <div class="middle-header">
            <div class="container h-100" >
                <div class="row h-100 align-items-center">
                    <!-- Logo Area -->
                    <div class="col-12 col-md-4">
                        <div class="logo-area">
                            <a href="index.php"><img src="img/core-img/headerlogo.jpg" alt="logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Bottom Header Area -->
        <div class="bottom-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="main-menu">
                            <nav class="navbar navbar-expand-lg">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#gazetteMenu" aria-controls="gazetteMenu" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i> Menu</button>
                                <div class="collapse navbar-collapse" id="gazetteMenu">
                                    <ul class="navbar-nav mr-auto">
                                        <li class="nav-item">
                                            <a class="nav-link" href="index.php">Home</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="catagory.php">Category</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="about-us.php">About Us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="contact.php">Contact Us</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="login.php">Sign In</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">Regional Setting</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">
										<?php	
											if(empty($_COOKIE['country'])&&empty($_COOKIE['language']))
								{
									echo"&emsp; &emsp;Country: ";
									echo"-";
									
									echo"&emsp; Language: ";
									echo"-";
									
								}
								else
								{
									echo"Country: ";
									echo $_COOKIE['country'];
									
									echo"&emsp; Language: ";
									echo $_COOKIE['language'];
									
								}
							?></a>
                                        </li>
                                     </ul>
                                    
									<?php
									if(!empty($_SESSION['login_user'])){
										echo $_SESSION['login_user']; 
									}
                                    else
                                        echo "";										
                                    ?>
									 
									
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Welcome Blog Slide Area Start -->
    <section class="welcome-blog-post-slide owl-carousel">
        <!-- Single Blog Post -->
        <div class="single-blog-post-slide bg-img background-overlay-5" style="background-image: url(img/core-img/car.jpg);">
            <!-- Single Blog Post Content -->
            <div class="single-blog-post-content">
                <div class="tags">
                    <a href="carsafety.php">Road Safety</a>
                </div>
                <h3><a href="carsafety.php" class="font-pt">Car Safety</a></h3>
                <div class="date">
                    <a href="catagory.php">
					                    <?php
										date_default_timezone_set("Singapore");
										echo date("Y/m/d");
										?>
										</a>
                </div>
            </div>
        </div>
        <!-- Single Blog Post -->
        <div class="single-blog-post-slide bg-img background-overlay-5" style="background-image: url(img/core-img/doorlock.jpeg);">
            <!-- Single Blog Post Content -->
            <div class="single-blog-post-content">
                <div class="tags">
                    <a href="theft.php">Safety House Program</a>
                </div>
                <h3><a href="theft.php" class="font-pt">ANTI-THEFT</a></h3>
                <div class="date">
                    <a href="catagory.php"><?php
										date_default_timezone_set("Singapore");
										echo date("Y/m/d");
										?></a>
                </div>
            </div>
        </div>
        <!-- Single Blog Post -->
        <div class="single-blog-post-slide bg-img background-overlay-5" style="background-image: url(img/core-img/hiv.jpg);">
            <!-- Single Blog Post Content -->
            <div class="single-blog-post-content">
                <div class="tags">
                    <a href="hiv.php">Healthy Life Style</a>
                </div>
                <h3><a href="hiv.php" class="font-pt">HIV </a></h3>
                <div class="date">
                    <a href="catagory.php"><?php
										date_default_timezone_set("Singapore");
										echo date("Y/m/d");
										?></a>
                </div>
            </div>
        </div>
        <!-- Single Blog Post -->
        <div class="single-blog-post-slide bg-img background-overlay-5" style="background-image: url(img/core-img/bbcnews.jpg);">
            <!-- Single Blog Post Content -->
            <div class="single-blog-post-content">
                <div class="tags">
                    <a href="live.php">live</a>
                </div>
                <h3><a href="live.php" class="font-pt">The Latest News Live</a></h3>
                <div class="date">
                    <a href="catagory.php"><?php
										date_default_timezone_set("Singapore");
										echo date("Y/m/d");
										?></a>
                </div>
            </div>
        </div>
    </section>
    <!-- Welcome Blog Slide Area End -->

    <!-- Latest News Marquee Area Start -->
    <div class="latest-news-marquee-area">
        <div class="simple-marquee-container">
            <div class="marquee">
                <ul class="marquee-content-items">
                    <li>
                        <a href="#"><span class="latest-news-time">10:40</span>Continuous Heavy Car Accident just happened in Seberang Jaya.</a>
                    </li>
                    <li>
                        <a href="#"><span class="latest-news-time">11:02</span>There is a theif with armed broke in the house of EX-Prime Minister of Malaysia.</a>
                    </li>
                    <li>
                        <a href="#"><span class="latest-news-time">12:37</span>There is a group of gangster taking drugs and fight with teachers in school of Pahang.</a>
                    </li>
                    <li>
                        <a href="#"><span class="latest-news-time">13:59</span>There is a mysterious holy water founded in INTI International College Penang.</a>
                    </li>
					<li>
                        <a href="#"><span class="latest-news-time">00:00</span>A troll king Ken is founded in INTI International College Penang.</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Latest News Marquee Area End -->
     <br>
    <!-- Main Content Area Start -->
    <section class="main-content-wrapper section_padding_0">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-9">
                    <!-- Gazette Welcome Post -->
                    <div class="gazette-welcome-post">
                        <!-- Post Tag -->
                        <div class="gazette-post-tag">
                            <a href="#">SAFETY. FOR A CHANGE.</a>
                        </div>
                        <h2 class="font-pt">Why Safety is important?</h2>
                        <p class="gazette-post-date">
						<body onload="startTime()">

						<div id="txt"></div>
										</p>
                        <!-- Post Thumbnail -->
                        <div class="blog-post-thumbnail my-5">
                            <img src="img/core-img/family.jpg" alt="post-thumb">
                        </div>
                        <!-- Post Excerpt -->
                        <p>A serious workplace injury or death changes lives forever – for families, friends, communities, and coworkers too. Human loss and suffering is immeasurable.  Occupational injuries and illnesses can provoke major crises for the families in which they occur. In addition to major financial burdens, they can impose substantial time demands on uninjured family members. Today, when many families are operating with very little free time, family resources may be stretched to the breaking point. Every person who leaves for work in the morning should expect to return home at night in good health. Can you imagine the knock on the door to tell you your loved one will never be returning home? Or the phone call to say he’s in the hospital and may never walk again? Ensuring that husbands return to their wives, wives to their husbands, parents to their children, and friends to their friends — that is the most important reason to create a safe and healthy work environment. But it isn’t the only reason. REDUCING INJURIES REDUCES COSTS TO YOUR BUSINESS: If a worker is injured on the job, it costs the company in lost work hours, increased insurance rates, workers' compensation premiums and possible litigation. Productivity is lost when other workers have to stop work to deal with the injury. Even after the injured employee has been sent home or taken to the hospital, other employees may be distracted or need to take time off from work in the aftermath of the incident. Even a single injury can have far-reaching and debilitating effects on your business. SAFE WORKERS ARE LOYAL WORKERS: Any business knows that employee attrition and absenteeism can be major obstacles. When you create a healthy and safe workplace, you reduce those issues in several ways. By budgeting for safety improvements and making safety part of your operational plan, you engender trust. By involving employees in safety decisions—through reporting, committees, walk-throughs and meetings—you show that their opinion matters to you. By following through on their input and improving safety, you prove quite tangibly that you care about their well-being. Workers typically respond by working harder, showing more pride in their jobs and remaining loyal. SAFETY IMPROVES QUALITY: Time and again, companies that put safety first turn out higher quality products. In some cases, that’s because a safe workplace tends to be a more efficient one, free of debris and tangles of cords. In other cases, it’s a matter of focus. By working in a clean, efficient environment, workers are able to reduce distractions and truly focus on the quality of what they do. The results? Better products that create customer loyalty, bigger margins and increased sales. In these ways and others workplace safety is about much more than legislation. It’s about creating the kind of productive, efficient, happy and inspiring workplace we all want to be part of. It’s about creating a highly profitable company. And that’s why it’s important.</p>
                        <!-- Reading More -->
                        <div class="post-continue-reading-share d-sm-flex align-items-center justify-content-between mt-30">
                            <div class="post-share-btn-group">
                                <a href="https://www.pinterest.com"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                <a href="https://www.linkedin.com/"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                <a href="https://www.facebook.com/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="https://twitter.com/?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>

                    <div class="gazette-todays-post section_padding_100_50">
                        <div class="gazette-heading">
                            <h4>today’s most popular</h4>
                        </div>
                        <!-- Single Today Post -->
                        <div class="gazette-single-todays-post d-md-flex align-items-start mb-50">
                            <div class="todays-post-thumb">
                                <img src="img/blog-img/2.jpg" alt="">
                            </div>
                            <div class="todays-post-content">
                                <!-- Post Tag -->
                                <div class="gazette-post-tag">
                                    <a href="https://edition.cnn.com/style/article/most-expensive-home-250-million-usd/index.php">News</a>
                                </div>
                                <h3><a href="https://edition.cnn.com/style/article/most-expensive-home-250-million-usd/index.php" class="font-pt mb-2">$250-million mansion is most expensive</a></h3>
                                <span class="gazette-post-date mb-2">March 29, 2016</span>
                                <a href="#" class="post-total-comments">3 Comments</a>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse ultrices egestas nunc, quis venenatis orci tincidunt id. Fusce commodo blandit eleifend. Nullam viverra tincidunt dolor, at pulvinar dui. Nullam at risus ut ipsum viverra posuere.</p>
                            </div>
                        </div>
                        <!-- Single Today Post -->
                        <div class="gazette-single-todays-post d-md-flex align-items-start mb-50">
                            <div class="todays-post-thumb">
                                <img src="img/blog-img/3.jpg" alt="">
                            </div>
                            <div class="todays-post-content">
                                <!-- Post Tag -->
                                <div class="gazette-post-tag">
                                    <a href="https://edition.cnn.com/2017/12/13/europe/homeless-man-paris-airport-theft-intl/index.php">Life</a>
                                </div>
                                <h3><a href="https://edition.cnn.com/2017/12/13/europe/homeless-man-paris-airport-theft-intl/index.php" class="font-pt mb-2">Homeless man steals $350,000 </a></h3>
                                <p class="gazette-post-date mb-2">March 29, 2016</p>
                                <a href="#" class="post-total-comments">3 Comments</a>
                                <p>Aliquam quis convallis enim. Nunc pulvinar molestie sem id blandit. Nunc venenatis interdum mollis. Aliquam finibus nulla quam, a iaculis justo finibus non. Suspendisse in fermentum nunc.</p>
                            </div>
                        </div>
                    </div>
                </div>
	
                <div class="col-12 col-lg-3 col-md-6">
                    <div class="sidebar-area">
                        <!-- Breaking News Widget -->
                        <div class="breaking-news-widget">
                            <div class="widget-title">
                                <h5>breaking news</h5>
                            </div>
                            <!-- Single Breaking News Widget -->
                            <div class="single-breaking-news-widget">
                                <img src="img/core-img/wtf.jpg" alt="">
                                <div class="breakingnews-title">
                                    <p>breaking news</p>
                                </div>
                                <div class="breaking-news-heading gradient-background-overlay">
                                    <h5 class="font-pt">Four People Killed In Car Crash In Chula Vista</h5>
                                </div>
                            </div>
                            <!-- Single Breaking News Widget -->
                            <div class="single-breaking-news-widget">
                                <img src="img/core-img/hivs.jpeg" alt="">
                                <div class="breakingnews-title">
                                    <p>breaking news</p>
                                </div>
                                <div class="breaking-news-heading gradient-background-overlay">
                                    <h5 class="font-pt">HIV/AIDS cure finally FOUND Doctors</h5>
                                </div>
                            </div>
                        </div>

                        <!-- Don't Miss Widget -->
                        <div class="donnot-miss-widget">
                            <div class="widget-title">
                                <h5>Don't miss</h5>
                            </div>
                            <!-- Single Don't Miss Post -->
                            <div class="single-dont-miss-post d-flex mb-30">
                                <div class="dont-miss-post-thumb">
                                    <img src="img/blog-img/dm-1.jpg" alt="">
                                </div>
                                <div class="dont-miss-post-content">
                                    <a href="#" class="font-pt">EU council reunites</a>
                                    <span>Nov 29, 2017</span>
                                </div>
                            </div>
                            <!-- Single Don't Miss Post -->
                            <div class="single-dont-miss-post d-flex mb-30">
                                <div class="dont-miss-post-thumb">
                                    <img src="img/blog-img/dm-2.jpg" alt="">
                                </div>
                                <div class="dont-miss-post-content">
                                    <a href="#" class="font-pt">A new way to travel the world</a>
                                    <span>March 29, 2016</span>
                                </div>
                            </div>
                            <!-- Single Don't Miss Post -->
                            <div class="single-dont-miss-post d-flex mb-30">
                                <div class="dont-miss-post-thumb">
                                    <img src="img/blog-img/dm-3.jpg" alt="">
                                </div>
                                <div class="dont-miss-post-content">
                                    <a href="#" class="font-pt">Why choose a bank?</a>
                                    <span>March 29, 2016</span>
                                </div>
                            </div>
                        </div>
                        <!-- Advert Widget -->
                        <div class="advert-widget">
                            <div class="widget-title">
                                <h5>Insurance</h5>
                            </div>
                            <div class="advert-thumb mb-30">
                                <a href="https://prudential.com.my/"><img src="img/core-img/insurance.png" alt=""></a>
                            </div>
                        </div>
                        <!-- Subscribe Widget -->
                        <div class="subscribe-widget">
                            <div class="widget-title">
                                <h5>subscribe</h5>
                            </div>
						  
                            <div class="subscribe-form">
                                <form action="index.php" method="POST">
                                    <input type="email" name="email" id="subs_email" placeholder="Your Email" required>   
                                    <button type="submit" name="submitted" onclick="alert('Thanks for subscribing us')">Subscribe</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Area End -->
		 <!-- Welcome Blog Slide Area Start -->
		 
		  
		<section class="welcome-blog-post-slide owl-carousel" width="1500" height ="3000">
			<!-- Single Blog Post -->
			<img src="img/core-img/EP.jpg" alt="Eyewear Protection"  />
				
			<!-- Single Blog Post -->
			<img src="img/core-img/clearRP.jpg" alt="Safety, visibility and durability" />
			
			<!-- Single Blog Post -->
			<img src="img/core-img/RP.jpg" alt="Respiratory Protection" />  
						
			<!-- Single Blog Post -->
		   <img src="img/core-img/SS.png" alt="Safe Shoes" />
	 
		</section>
	
 
                   
								<!-- END: JA SLIDER -->

    <!-- Footer Area Start -->
    <footer class="footer-area bg-img background-overlay" style="background-image: url(img/core-img/belowlogo.jpg)";>
        <!-- Top Footer Area -->
        <div class="top-footer-area section_padding_100_70" >
            <div class="container">
                <div class="row">
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Helmet</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.bellhelmets.com/en_ap/">Bell</a></li>
                                <li><a href="http://nextarjapan.com/?gclid=CjwKCAjw4avaBRBPEiwA_ZetYkPqgtEBtnmUpGhoGOrKdOpCJU933gyCp0dybEDVG-r5uji8OJ1nlRoCjFAQAvD_BwE">Arai</a></li>
                                <li><a href="http://www.hjchelmets.com/">HJC</a></li>
                                <li><a href="https://www.motoin.de/Helmets/Integral-Helmets/Shoei-GT-Air-Exposure-integral-helmet::35504.html?language=en&gclid=CjwKCAjw4avaBRBPEiwA_ZetYnY0hxkvOSFPLdR8hQHSWLobDicU1XZL3_1HpEmVToTXaDjzTAvYgRoCpdMQAvD_BwE">Shoei</a></li>
                                <li><a href="https://www.motoin.de/AGV:.:101.html?tpl=clear&country=GI&language=en&gclid=CjwKCAjw4avaBRBPEiwA_ZetYsScOVABDo-snmdm0VmS1NgXSLqYGuvnotdU3_vA3Yrr55lXKmbnwhoCo9YQAvD_BwE">AGV</a></li>
                                <li><a href="https://1outlets.my/go/Nolan+Helmets?gclid=CjwKCAjw4avaBRBPEiwA_ZetYmSjkGhMXMxDuGjyNtffDIHZmpb0KN58jurk1bU9d5BbPp5kX-g4cxoCKDsQAvD_BwE">Nolan</a></li>
                                <li><a href="http://www.shark-helmets.com/">Shark</a></li>
                                <li><a href="https://www.schuberth.com/en.html">Schuberth</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Gloves</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Ultimate Industrial</a></li>
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Super Touch</a></li>
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Ansell</a></li>
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Top Glove</a></li>
								<li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Unigloves</a></li>
								<li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Bodyguards</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Boots</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Alden</a></li>
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Ariat</a></li>
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Blundstones</a></li>
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Chippewa</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Doc Martens</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">The Frye Company</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Hush Puppies</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Meindl</a></li>
							</ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Glasses</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Uvex</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">AO</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Crews</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">DeWALT</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Wiley-X</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Equestrian</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">GoogleWear</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Lexa</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Earmuff</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Leightning</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Elvex</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">QuieTunes</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">3M Peltor</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Pro Guard</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Electro Digital Radio</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Golden Eagle</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">+More</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="catagory.php">Category</a></li>
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                                <li><a href="catagory-transportation.php">Transportation</a></li>
                                <li><a href="catagory-security.php">Security</a></li>
                                <li><a href="catagory-health.php">Health</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bottom Footer Area -->
        <div class="bottom-footer-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12">
                        <div class="copywrite-text">
                            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area End -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
<?php
	}
?>
</body>

</html>