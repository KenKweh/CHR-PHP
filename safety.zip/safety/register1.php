<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Safety First - Make The World A Better Place | Contact</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">

</head>
<script>
	function startTime() {
		var today = new Date();
		var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
		var d = today.getDate();
		var mn = today.getMonth();
		var y = today.getFullYear();
		var h = today.getHours();
		var m = today.getMinutes();
		var s = today.getSeconds();
		m = checkTime(m);
		s = checkTime(s);
		document.getElementById('txt').innerHTML =
		d + " " + months[today.getMonth()] + " " + y + " " + h + ":" + m + ":" + s;
		var t = setTimeout(startTime, 500);
	}
	function checkTime(i) {
		if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
		return i;
	}
</script>

<body>
    <!-- Header Area Start -->
    <header class="header-area">
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <!-- Breaking News Area -->
                    <div class="col-12 col-md-6">
                        <div class="breaking-news-area">
                            <h5 class="breaking-news-title">Register now for more information</h5>
                        </div>
                    </div>
                    <!-- Stock News Area -->
                    <div class="col-12 col-md-6">
                        <div class="stock-news-area">
                            <div id="stockNewsTicker" class="ticker">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Middle Header Area -->
        <div class="middle-header">
            <div class="container h-100" >
                <div class="row h-100 align-items-center">
                    <!-- Logo Area -->
                    <div class="col-12 col-md-4">
                        <div class="logo-area">
                            <a href="index.php"><img src="img/core-img/headerlogo.jpg" alt="logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		
		
        <!-- Bottom Header Area -->
        <div class="bottom-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="main-menu">
                            <nav class="navbar navbar-expand-lg">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#gazetteMenu" aria-controls="gazetteMenu" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i> Menu</button>
                                <div class="collapse navbar-collapse" id="gazetteMenu">
                                    <ul class="navbar-nav mr-auto">
                                         <li class="nav-item">
                                            <a class="nav-link" href="index.php">Home</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="catagory.php">Category</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="about-us.php">About Us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="contact.php">Contact Us</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="register.php">Register</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="login.php">Sign In</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">Regional Setting</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">
											<?php
	
											if(empty($_COOKIE['country'])&&empty($_COOKIE['language']))
								{
									echo"&emsp; &emsp;Country: ";
									echo"-";
									
									echo"&emsp; Language: ";
									echo"-";
									
								}
								else
								{
									echo"Country: ";
									echo $_COOKIE['country'];
									
									echo"&emsp; Language: ";
									echo $_COOKIE['language'];
									
								}
							?></a>
                                        </li>
                                     </ul>
                                    <!-- Search Form -->
                                    <div class="header-search-form mr-auto">
                                        <form action="#">
                                            <input type="search" placeholder="Input your keyword then press enter..." id="search" name="search">
                                            <input class="d-none" type="submit" value="submit">
                                        </form>
                                    </div>
                                    <!-- Search btn -->
                                    <div id="searchbtn">
                                        <i class="fa fa-search" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Breadcumb Area Start -->
    <div class="breadcumb-area section_padding_50">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breacumb-content d-flex align-items-center justify-content-between">
                        <h1 class="font-pt mb-0">Sorry</h1>
                        <body onload="startTime()">

						<div id="txt"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area End -->

    <section class="gazette-contact-area section_padding_100">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8">
                    <div class="gazette-heading">
                        <h1 class="font-bold">The password and the confirm password are different.</h1>
						<h1 class="font-bold">Please try again.<br></h1><br>
                    </div>
                    <br><br><br>
							<a class="btn contact-btn" href="register.php"><b>OK</b></a>
							</form>