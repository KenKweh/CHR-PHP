<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Safety First - Make The World A Better Place | Catagory</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/bear.png">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">

</head>
<script>
	function startTime() {
		var today = new Date();
		var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
		var d = today.getDate();
		var mn = today.getMonth();
		var y = today.getFullYear();
		var h = today.getHours();
		var m = today.getMinutes();
		var s = today.getSeconds();
		m = checkTime(m);
		s = checkTime(s);
		document.getElementById('txt').innerHTML =
		d + " " + months[today.getMonth()] + " " + y + " " + h + ":" + m + ":" + s;
		var t = setTimeout(startTime, 500);
	}
	function checkTime(i) {
		if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
		return i;
	}
</script>

<?php
session_start();
                 
?>
<body>
    <!-- Header Area Start -->
    <header class="header-area">
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <!-- Breaking News Area -->
                    <div class="col-12 col-md-6">
                        <div class="breaking-news-area">
                            <h5 class="breaking-news-title">Safety Quotes</h5>
							<div id="breakingNewsTicker" class="ticker">
                                <ul>
                                    <li><a href="#">For safety is not a gadget but a state of mind.</a></li>
                                    <li><a href="#">Safety is as simple as ABC - Always Be Careful.</a></li>
                                    <li><a href="#">The desire for safety stands against every great and noble enterprise.</a></li>
                                    <li><a href="#">The dangers of life are infinite, and among them is safety.</a></li>
                                    <li><a href="#">It is better to be safe than sorry.</a></li>
                                    <li><a href="#">Safety is something that happens between your ears, not something you hold in your hands.</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- Stock News Area -->
                    <div class="col-12 col-md-6">
                        <div class="stock-news-area">
                            <div id="stockNewsTicker" class="ticker">
                                <ul>
                                    <li>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>Accident Rate</span>
                                                <span>2014</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>0.34</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>HIV RATE</span>
                                                <span>2014</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.27</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>THEFT RATE</span>
                                                <span>2014</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.22</h4>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>ACCIDENT RATE</span>
                                                <span>2015</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>0.11</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>HIV RATE</span>
                                                <span>2015</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>0.77</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>THEFT RATE</span>
                                                <span>2015</span>
                                            </div>
                                            <div class="stock-index minus-index">
                                                <h4>1.25</h4>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>ACCIDENT RATE</span>
                                                <span>2016</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.04</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>HIV RATE</span>
                                                <span>2016</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.08</h4>
                                            </div>
                                        </div>
                                        <div class="single-stock-report">
                                            <div class="stock-values">
                                                <span>THEFT RATE</span>
                                                <span>2016</span>
                                            </div>
                                            <div class="stock-index plus-index">
                                                <h4>0.12</h4>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Middle Header Area -->
        <div class="middle-header">
            <div class="container h-100" >
                <div class="row h-100 align-items-center">
                    <!-- Logo Area -->
                    <div class="col-12 col-md-4">
                        <div class="logo-area">
                            <a href="index.php"><img src="img/core-img/headerlogo.jpg" alt="logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Bottom Header Area -->
        <div class="bottom-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="main-menu">
                            <nav class="navbar navbar-expand-lg">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#gazetteMenu" aria-controls="gazetteMenu" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i> Menu</button>
                                <div class="collapse navbar-collapse" id="gazetteMenu">
                                    <ul class="navbar-nav mr-auto">
                                       <li class="nav-item">
                                            <a class="nav-link" href="index.php">Home</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="catagory.php">Category</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="about-us.php">About Us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="contact.php">Contact Us</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="login.php">Sign Out</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">Regional Setting</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">
											<?php
	
											if(empty($_COOKIE['country'])&&empty($_COOKIE['language']))
								{
									echo"&emsp; &emsp;Country: ";
									echo"-";
									
									echo"&emsp; Language: ";
									echo"-";
									
								}
								else
								{
									echo"Country: ";
									echo $_COOKIE['country'];
									
									echo"&emsp; Language: ";
									echo $_COOKIE['language'];
									
								}
							?></a>
                                        </li>
                                     </ul>
                                   <?php
									if(!empty($_SESSION['login_user'])){
										echo "USERNAME: ";
										echo $_SESSION['login_user']; 
									}
                                    else
                                        echo "";										
                                    ?>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Breadcumb Area Start -->
    <div class="breadcumb-area section_padding_50">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breacumb-content d-flex align-items-center justify-content-between">
                        <!-- Post Tag -->
                        
                             <h1 class="font-pt mb-0">CATEGORY</h1>
                        
                        <body onload="startTime()">

						<div id="txt"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area End -->

    <!-- Editorial Area Start -->
    <section class="gazatte-editorial-area section_padding_100 bg-dark">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="editorial-post-slides owl-carousel">

                        <!-- Editorial Post Single Slide -->
                        <div class="editorial-post-single-slide">
                            <div class="row">
                                <div class="col-12 col-md-5">
                                    <div class="editorial-post-thumb">
                                        <img src="img/core-img/light.JPG" alt="">
                                    </div>
                                </div>
                                <div class="col-12 col-md-7">
                                    <div class="editorial-post-content">
                                        <!-- Post Tag -->
                                        <div class="gazette-post-tag">
                                            <a href="catagory-transportation.php">TRANSPORTATION</a>
                                        </div>
                                        <h2><a href="catagory-transportation.php" class="font-pt mb-15">What is Transportation?</a></h2>
                                        <p class="editorial-post-date mb-15">March 29, 2016</p>
                                        <p>Road traffic safety refers to the methods and measures used to prevent road users from being killed or seriously injured. Typical road users include: pedestrians, cyclists, motorists, vehicle passengers, horse-riders and passengers of on-road public transport (mainly buses and trams).</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Editorial Post Single Slide -->
                        <div class="editorial-post-single-slide">
                            <div class="row">
                                <div class="col-12 col-md-5">
                                    <div class="editorial-post-thumb">
                                        <img src="img/core-img/doctor.jpg" alt="">
                                    </div>
                                </div>
                                <div class="col-12 col-md-7">
                                    <div class="editorial-post-content">
                                        <!-- Post Tag -->
                                        <div class="gazette-post-tag">
                                            <a href="catagory-health.php">HEALTH</a>
                                        </div>
                                        <h2><a href="catagory-health.php" class="font-pt mb-15">What is Health?</a></h2>
                                        <p class="editorial-post-date mb-15">March 29, 2016</p>
                                        <p>Health is the ability of a biological system to acquire, convert, allocate, distribute, and utilize energy with maximum efficiency. The World Health Organization (WHO) defined human health in a broader sense in its 1948 constitution as "a state of complete physical, mental and social well-being and not merely the absence of disease or infirmity." This definition has been subject to controversy, in particular as lacking operational value, the ambiguity in developing cohesive health strategies and because of the problem created by use of the word "complete", which makes it practically impossible to achieve. Other definitions have been proposed, among which a recent definition that correlates health and personal satisfaction.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Editorial Post Single Slide -->
                        <div class="editorial-post-single-slide">
                            <div class="row">
                                <div class="col-12 col-md-5">
                                    <div class="editorial-post-thumb">
                                        <img src="img/core-img/security.jpg" alt="">
                                    </div>
                                </div>
                                <div class="col-12 col-md-7">
                                    <div class="editorial-post-content">
                                        <!-- Post Tag -->
                                        <div class="gazette-post-tag">
                                            <a href="catagory-security.php">SECURITY</a>
                                        </div>
                                        <h2><a href="catagory-security.php" class="font-pt mb-15">What is Security?</a></h2>
                                        <p class="editorial-post-date mb-15">March 29, 2016</p>
                                        <p>Security is freedom from, or resilience against, potential harm (or other unwanted coercive change) from external forces. Beneficiaries (technically referents) of security may be persons and social groups, objects and institutions, ecosystems, and any other entity or phenomenon vulnerable to unwanted change by its environment.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Area Start -->
    <footer class="footer-area bg-img background-overlay" style="background-image: url(img/core-img/belowlogo.jpg)";>
        <!-- Top Footer Area -->
        <div class="top-footer-area section_padding_100_70" >
            <div class="container">
                <div class="row">
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Helmet</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.bellhelmets.com/en_ap/">Bell</a></li>
                                <li><a href="http://nextarjapan.com/?gclid=CjwKCAjw4avaBRBPEiwA_ZetYkPqgtEBtnmUpGhoGOrKdOpCJU933gyCp0dybEDVG-r5uji8OJ1nlRoCjFAQAvD_BwE">Arai</a></li>
                                <li><a href="http://www.hjchelmets.com/">HJC</a></li>
                                <li><a href="https://www.motoin.de/Helmets/Integral-Helmets/Shoei-GT-Air-Exposure-integral-helmet::35504.html?language=en&gclid=CjwKCAjw4avaBRBPEiwA_ZetYnY0hxkvOSFPLdR8hQHSWLobDicU1XZL3_1HpEmVToTXaDjzTAvYgRoCpdMQAvD_BwE">Shoei</a></li>
                                <li><a href="https://www.motoin.de/AGV:.:101.html?tpl=clear&country=GI&language=en&gclid=CjwKCAjw4avaBRBPEiwA_ZetYsScOVABDo-snmdm0VmS1NgXSLqYGuvnotdU3_vA3Yrr55lXKmbnwhoCo9YQAvD_BwE">AGV</a></li>
                                <li><a href="https://1outlets.my/go/Nolan+Helmets?gclid=CjwKCAjw4avaBRBPEiwA_ZetYmSjkGhMXMxDuGjyNtffDIHZmpb0KN58jurk1bU9d5BbPp5kX-g4cxoCKDsQAvD_BwE">Nolan</a></li>
                                <li><a href="http://www.shark-helmets.com/">Shark</a></li>
                                <li><a href="https://www.schuberth.com/en.html">Schuberth</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Gloves</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Ultimate Industrial</a></li>
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Super Touch</a></li>
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Ansell</a></li>
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Top Glove</a></li>
								<li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Unigloves</a></li>
								<li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Bodyguards</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Boots</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Alden</a></li>
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Ariat</a></li>
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Blundstones</a></li>
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Chippewa</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Doc Martens</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">The Frye Company</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Hush Puppies</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Meindl</a></li>
							</ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Glasses</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Uvex</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">AO</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Crews</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">DeWALT</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Wiley-X</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Equestrian</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">GoogleWear</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Lexa</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Earmuff</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Leightning</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Elvex</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">QuieTunes</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">3M Peltor</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Pro Guard</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Electro Digital Radio</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Golden Eagle</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">+More</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="catagory.php">Category</a></li>
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                                <li><a href="catagory-transportation.php">Transportation</a></li>
                                <li><a href="catagory-security.php">Security</a></li>
                                <li><a href="catagory-health.php">Health</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bottom Footer Area -->
        <div class="bottom-footer-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12">
                        <div class="copywrite-text">
                            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area End -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>