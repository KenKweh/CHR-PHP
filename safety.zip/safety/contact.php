<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Safety First - Make The World A Better Place | Contact</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/bear.png">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">

</head>
<script>
	function startTime() {
		var today = new Date();
		var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
		var d = today.getDate();
		var mn = today.getMonth();
		var y = today.getFullYear();
		var h = today.getHours();
		var m = today.getMinutes();
		var s = today.getSeconds();
		m = checkTime(m);
		s = checkTime(s);
		document.getElementById('txt').innerHTML =
		d + " " + months[today.getMonth()] + " " + y + " " + h + ":" + m + ":" + s;
		var t = setTimeout(startTime, 500);
	}
	function checkTime(i) {
		if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
		return i;
	}
</script>

<?php
session_start();              
?>
<body>
<?php 
                    if(isset($_POST['Submitted']))
					{ 
                  {
				         if((!empty($_POST['contact-name'])) && (!empty($_POST['contact-email'])) && (!empty($_POST['message'])))
						 {
								header('Location:index.php');
								exit();
							   
					      }	
						  else { 
							echo "Please fill the feedback form completely before submit. Thank you!";
								}
						  
				   }	
			           
					}	
					else 	{ 
?>					
    <!-- Header Area Start -->
    <header class="header-area">
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <!-- Breaking News Area -->
                    <div class="col-12 col-md-6">
                        <div class="breaking-news-area">
                            <h5 class="breaking-news-title">We always listen and react to your comments</h5>							
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Middle Header Area -->
        <div class="middle-header">
            <div class="container h-100" >
                <div class="row h-100 align-items-center">
                    <!-- Logo Area -->
                    <div class="col-12 col-md-4">
                        <div class="logo-area">
                            <a href="index.php"><img src="img/core-img/headerlogo.jpg" alt="logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Bottom Header Area -->
        <div class="bottom-header">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="main-menu">
                            <nav class="navbar navbar-expand-lg">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#gazetteMenu" aria-controls="gazetteMenu" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i> Menu</button>
                                <div class="collapse navbar-collapse" id="gazetteMenu">
                                    <ul class="navbar-nav mr-auto">
                                          <li class="nav-item">
                                            <a class="nav-link" href="index.php">Home</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="catagory.php">Category</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="about-us.php">About Us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="contact.php">Contact Us</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="login.php">Sign In</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">Regional Setting</a>
                                        </li>
										  <li class="nav-item">
                                            <a class="nav-link" href="regional.php">
											<?php
				                             //when no value
	                                         if(empty($_COOKIE['country'])&&empty($_COOKIE['language'])&&empty($_COOKIE['currency']))
							            	{
									             echo"Country: ";
									             echo"-";
									
									             echo"&emsp; Language: ";
									             echo"-";								
								            }
								            //when have value
								            else
								            {
									             echo"Country: ";
									             echo $_COOKIE['country'];
									
									             echo"&emsp; Language: ";
									             echo $_COOKIE['language'];								
								            }
							            ?></a>
                                        </li>
                                     </ul>
                                   <?php
									if(!empty($_SESSION['login_user'])){
										echo $_SESSION['login_user']; 
									}
                                    else
                                        echo "";										
                                    ?>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Breadcumb Area Start -->
    <div class="breadcumb-area section_padding_50">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breacumb-content d-flex align-items-center justify-content-between">
                         <h1 class="font-pt mb-0">Contact</h1>
                        <body onload="startTime()">

						<div id="txt"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area End -->

    <section class="gazette-contact-area section_padding_100">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8">
                    <div class="gazette-heading">
                        <h4 class="font-bold">Feedback</h4>
                    </div>
                    <!-- Contact Form -->
							
				   <form action="contact.php" method="post">
						
                        <div class="form-group">
                            <input type="text" class="form-control" name="contact-name" required name="contact-name" placeholder="Enter Your Full Name">
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" name="contact-email" required name="contact-email" placeholder="Email">
                        </div>
						<div class="form-group">
                                        <select class="form-control" style="height:50px; color:#8c8c8c;" id="States">
                                        <option value="qts">Questions</option>
                                        <option value="sgt">Suggestions</option>
                                        <option value="cpl">Compliments</option>
                                        <option value="cpn">Complains</option>
                                        <option value="oth">Others</option>                                       
                                    </select>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="message" cols="30" rows="10" required name="message" placeholder="Message" required></textarea>
                        </div>
                        <button type="submit" name="Submitted" class="btn contact-btn" onclick="alert('Thanks for your feedback! Wish you have a good day! ')">SUBMIT<i class="fa fa-angle-right ml-2"></i></button>
                    </form>					
                </div>
                        <div class="col-12 col-md-4">
                            <div class="gazette-heading">
                                <h4 class="font-bold">address</h4>
                            </div>
                            <div class="contact-address-info mb-50">
                                <p>Address: Z-1, Lebuh Bukit Jambul,</p>
						        <p>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspBukit Jambul,</p>
						        <p>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp11900 Bayan Lepas,</p>
						        <p>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspPulau Pinang.</p>					
                            </div>
                            <div class="gazette-heading">
                                <h4 class="font-bold">Phone</h4>
                            </div>
                            <div class="contact-address-info">
                                <p>Phone #1: 126-632-2345 <br>Phone #2: 126-632-2345 <br>Phone #3: 126-632-2345 <br>Phone #4: 126-632-2345</p>
                            </div>
                        </div>
            </div>
        </div>
    </section>
<?php
					}
?>

    <!-- Footer Area Start -->
    <footer class="footer-area bg-img background-overlay" style="background-image: url(img/core-img/belowlogo.jpg)";>
        <!-- Top Footer Area -->
        <div class="top-footer-area section_padding_100_70" >
            <div class="container">
                <div class="row">
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Helmet</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.bellhelmets.com/en_ap/">Bell</a></li>
                                <li><a href="http://nextarjapan.com/?gclid=CjwKCAjw4avaBRBPEiwA_ZetYkPqgtEBtnmUpGhoGOrKdOpCJU933gyCp0dybEDVG-r5uji8OJ1nlRoCjFAQAvD_BwE">Arai</a></li>
                                <li><a href="http://www.hjchelmets.com/">HJC</a></li>
                                <li><a href="https://www.motoin.de/Helmets/Integral-Helmets/Shoei-GT-Air-Exposure-integral-helmet::35504.html?language=en&gclid=CjwKCAjw4avaBRBPEiwA_ZetYnY0hxkvOSFPLdR8hQHSWLobDicU1XZL3_1HpEmVToTXaDjzTAvYgRoCpdMQAvD_BwE">Shoei</a></li>
                                <li><a href="https://www.motoin.de/AGV:.:101.html?tpl=clear&country=GI&language=en&gclid=CjwKCAjw4avaBRBPEiwA_ZetYsScOVABDo-snmdm0VmS1NgXSLqYGuvnotdU3_vA3Yrr55lXKmbnwhoCo9YQAvD_BwE">AGV</a></li>
                                <li><a href="https://1outlets.my/go/Nolan+Helmets?gclid=CjwKCAjw4avaBRBPEiwA_ZetYmSjkGhMXMxDuGjyNtffDIHZmpb0KN58jurk1bU9d5BbPp5kX-g4cxoCKDsQAvD_BwE">Nolan</a></li>
                                <li><a href="http://www.shark-helmets.com/">Shark</a></li>
                                <li><a href="https://www.schuberth.com/en.html">Schuberth</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Gloves</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Ultimate Industrial</a></li>
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Super Touch</a></li>
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Ansell</a></li>
                                <li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Top Glove</a></li>
								<li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Unigloves</a></li>
								<li><a href="https://www.justgloves.co.uk/Shop-By-Brand">Bodyguards</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Boots</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Alden</a></li>
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Ariat</a></li>
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Blundstones</a></li>
                                <li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Chippewa</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Doc Martens</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">The Frye Company</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Hush Puppies</a></li>
								<li><a href="https://boxterfootwear.com.my/?gclid=CjwKCAjwhLHaBRAGEiwAHCgG3vsAP3zPLAQlbATwZIlzY-JFeht1FeUYASuSVH5W44lMT3CPl9OLwxoCLBQQAvD_BwE">Meindl</a></li>
							</ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Glasses</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Uvex</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">AO</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Crews</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">DeWALT</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Wiley-X</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Equestrian</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">GoogleWear</a></li>
                                <li><a href="https://www.safetyglassesusa.com/brandnames.html">Lexa</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">Earmuff</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Leightning</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Elvex</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">QuieTunes</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">3M Peltor</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Pro Guard</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Electro Digital Radio</a></li>
                                <li><a href="https://www.gemplers.com/safety-earmuffs">Golden Eagle</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-md-4 col-lg-2">
                        <div class="single-footer-widget">
                            <div class="footer-widget-title">
                                <h4 class="font-pt">+More</h4>
                            </div>
                            <ul class="footer-widget-menu">
                                <li><a href="catagory.php">Category</a></li>
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                                <li><a href="catagory-transportation.php">Transportation</a></li>
                                <li><a href="catagory-security.php">Security</a></li>
                                <li><a href="catagory-health.php">Health</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Bottom Footer Area -->
        <div class="bottom-footer-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12">
                        <div class="copywrite-text">
                            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area End -->


</body>
</html>